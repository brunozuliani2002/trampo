/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import java.util.ArrayList;
import java.util.List;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.ResultSet;


/**
 *
 * @author usuario
 */
public class CarrosAlugadosDAO {
    private int id;
    private int idClientes;
    private int idCarros;
    private String nomeClientes;
    private String enderecoClientes;
    private String telefoneClientes;
    private String nomeCarros;
    private int valorCarros;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdClientes() {
        return idClientes;
    }

    public void setIdClientes(int idClientes) {
        this.idClientes = idClientes;
    }

    public int getIdCarros() {
        return idCarros;
    }

    public void setIdCarros(int idCarros) {
        this.idCarros = idCarros;
    }

    public String getNomeClientes() {
        return nomeClientes;
    }

    public void setNomeClientes(String nomeClientes) {
        this.nomeClientes = nomeClientes;
    }

    public String getEnderecoClientes() {
        return enderecoClientes;
    }

    public void setEnderecoClientes(String enderecoClientes) {
        this.enderecoClientes = enderecoClientes;
    }

    public String getTelefoneClientes() {
        return telefoneClientes;
    }

    public void setTelefoneClientes(String telefoneClientes) {
        this.telefoneClientes = telefoneClientes;
    }

    public String getNomeCarros() {
        return nomeCarros;
    }

    public void setNomeCarros(String nomeCarros) {
        this.nomeCarros = nomeCarros;
    }

    public int getValorCarros() {
        return valorCarros;
    }

    public void setValorCarros(int valorCarros) {
        this.valorCarros = valorCarros;
    }

    public Connection getConecta() {
        return conecta;
    }

    public void setConecta(Connection conecta) {
        this.conecta = conecta;
    }

    private Connection conecta;

    // Construtores, getters e setters...

 public List<CarrosAlugadosDAO> listarCarrosAlugados() {
        List<CarrosAlugadosDAO> lista = new ArrayList<>();

        try {
            Connection conecta = new ConnectionFactory().conecta();

            String sql = "SELECT c.id, c.nomeClientes, c.telefoneClientes, c.enderecoClientes, car.nomeCarros, car.valorCarros " +
                    "FROM tbcarrosAlugados c " +
                    "JOIN tbcarros car ON c.idCarros = car.idcarros " +
                    "JOIN tbclientes cli ON c.idClientes = cli.idclientes";

            try (PreparedStatement stmt = conecta.prepareStatement(sql);
                 ResultSet rs = stmt.executeQuery()) {

                while (rs.next()) {
                    CarrosAlugadosDAO carroAlugado = new CarrosAlugadosDAO();
                    carroAlugado.setId(rs.getInt("id"));
                    carroAlugado.setNomeClientes(rs.getString("nomeClientes"));
                    carroAlugado.setTelefoneClientes(rs.getString("telefoneClientes"));
                    carroAlugado.setEnderecoClientes(rs.getString("enderecoClientes"));
                    carroAlugado.setNomeCarros(rs.getString("nomeCarros"));
                    carroAlugado.setValorCarros(rs.getInt("valorCarros"));

                    lista.add(carroAlugado);
                    System.out.println("Lista de carros alugados: " + lista);
                }

            } catch (SQLException e) {
                e.printStackTrace();
            }
        } finally {
            try {
                if (conecta != null && !conecta.isClosed()) {
                    conecta.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return lista;
}

}




