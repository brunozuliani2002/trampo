/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import java.sql.PreparedStatement;
import Javabeans.Carros;
import com.mysql.cj.protocol.Resultset;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import java.sql.ResultSet;


/**
 *
 * @author usuario
 */
public class CarrosDAO {

    private Connection conecta;

    public CarrosDAO() {
        this.conecta = new ConnectionFactory().conecta();

    }

public void cadastrarCarros(Carros obj) {
    try {
        String sql = "INSERT INTO tbcarros (nomecarros, anocarros, corcarros, valorcarros, fotocarros) VALUES (?, ?, ?, ?, ?)";

        try (PreparedStatement stmt = conecta.prepareStatement(sql)) {
            stmt.setString(1, obj.getNomecarros());
            stmt.setInt(2, obj.getAnocarros());
            stmt.setString(3, obj.getCorcarros());
            stmt.setInt(4, obj.getValorcarros());

           // Aqui, você deve verificar se a foto não é nula
            if (obj.getFotocarros()!= null) {
                // Se a foto não for nula, insira o array de bytes
                stmt.setBytes(5, obj.getFotocarros());
                
            } else {
                stmt.setNull(5, java.sql.Types.BLOB);
            }

            stmt.execute();
        }

        JOptionPane.showMessageDialog(null, "Cadastro com sucesso");
                // Se a foto for nula, insira NULL no banco de dados
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Erro ao cadastrar carro: " + e.getMessage());
    }
}

public void excluirCarros(Carros obj) {
        try {
            String cmdsql = "delete from tbcarros where idcarros = ?";

            try (PreparedStatement stmt = conecta.prepareStatement(cmdsql)) {
                stmt.setInt(1, obj.getIdcarros());
                
                stmt.execute();
            }

        } catch (SQLException erro) {
            throw new RuntimeException(erro);
        }
    }

public void editarCarros(Carros obj) {
    String sql = "UPDATE tbcarros SET nomecarros=?, anocarros=?, corcarros=?, valorcarros=?, fotocarros=? WHERE idcarros=?";

    try (PreparedStatement stmt = conecta.prepareStatement(sql)) {
        stmt.setString(1, obj.getNomecarros());
        stmt.setInt(2, obj.getAnocarros());
        stmt.setString(3, obj.getCorcarros());
        stmt.setInt(4, obj.getValorcarros());

        // Verifica se há uma imagem para atualizar
        if (obj.getFotocarros()!= null) {
            stmt.setBytes(5, obj.getFotocarros());
        } else {
            // Se não houver imagem, defina como null
            stmt.setNull(5, java.sql.Types.BLOB);
        }

        stmt.setInt(6, obj.getIdcarros());  // Substitua getId() pelo método que retorna o ID do objeto

        stmt.executeUpdate();
    } catch (SQLException e) {
        e.printStackTrace();
    }
}


public List<Carros> listarCarros() {
        String sql = "SELECT * FROM tbcarros";
        List<Carros> lista = new ArrayList<>();

        try (PreparedStatement stmt = conecta.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Carros carro = new Carros();
                carro.setNomecarros(rs.getString("nomecarros"));
                carro.setAnocarros(rs.getInt("anocarros"));
                carro.setCorcarros(rs.getString("corcarros"));
                carro.setValorcarros(rs.getInt("valorcarros"));

                // Alteração: recupera a imagem como um array de bytes
                byte[] foto = rs.getBytes("fotocarros");
                carro.setFotocarros(foto);

                lista.add(carro);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return lista;
    }

public void fecharConecta(){
        try {
        conecta.close();
    } catch (SQLException e) {
          e.printStackTrace();
    }

}
  public Carros obterCarroPorId(int id) {
        Carros carro = null;
        try {
            String sql = "SELECT * FROM tbcarros WHERE idcarros = ?";
            try (PreparedStatement stmt = conecta.prepareStatement(sql)) {
                stmt.setInt(1, id);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        carro = new Carros();
                        carro.setIdcarros(rs.getInt("idcarros"));
                        carro.setNomecarros(rs.getString("nomecarros"));
                        carro.setAnocarros(rs.getInt("anocarros"));
                        carro.setCorcarros(rs.getString("corcarros"));
                        carro.setValorcarros(rs.getInt("valorcarros"));
                        // Você pode precisar ajustar essa parte se estiver armazenando a foto como BLOB
                        carro.setFotocarros(rs.getBytes("fotocarros"));
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return carro;
    }

    public byte[] obterFotoCarroPorId(int idCarro) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
  
  
}




