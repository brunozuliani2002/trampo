package DAO;

import Javabeans.Clientes;
import java.util.List;
import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.sql.ResultSet;

public class ClientesDAO {

    private Connection conecta;

    public ClientesDAO() {
        this.conecta = new ConnectionFactory().conecta();
    }

    // Método para cadastrar cliente
    public void cadastrarCliente(Clientes obj) {
        try {
            String cmdsql = "INSERT INTO tbclientes (nometbclientes, enderecotbclientes, ntbclientes, bairrotbclientes, cidadetbclientes, telefonetbclientes) VALUES (?, ?, ?,?, ?,?)";

            PreparedStatement stmt = conecta.prepareStatement(cmdsql);
            stmt.setString(1, obj.getNometbclientes());
            stmt.setString(2, obj.getEnderecotbclientes());
            stmt.setString(3, obj.getNtbclientes());
            stmt.setString(4, obj.getBairrotbclientes());
            stmt.setString(5, obj.getCidadetbclientes());
            stmt.setString(6, obj.getTelefonetbclientes());

            stmt.execute();
            stmt.close();

        } catch (SQLException erro) {
            throw new RuntimeException(erro);
        }
    }

    // Método para editar clientes
    public void editarClientes(Clientes obj) {
        try {
            String cmdsql = "UPDATE tbclientes SET nometbclientes = ?, enderecotbclientes = ?,ntbclientes = ?,bairrotbclientes = ?, cidadetbclientes = ?, telefonetbclientes = ? WHERE idclientes = ?";

            PreparedStatement stmt = conecta.prepareStatement(cmdsql);
            stmt.setString(1, obj.getNometbclientes());
            stmt.setString(2, obj.getEnderecotbclientes());
             stmt.setString(3, obj.getNtbclientes());
              stmt.setString(4, obj.getBairrotbclientes());
            stmt.setString(5, obj.getCidadetbclientes());
            stmt.setString(6, obj.getTelefonetbclientes());         
            stmt.setInt(7, obj.getIdclientes());

            stmt.execute();
            stmt.close();

        } catch (SQLException erro) {
            throw new RuntimeException(erro);
        }
    }

    // Método para excluir clientes
    public void excluirClientes(Clientes obj) {
        try {
            String cmdsql = "DELETE FROM tbclientes WHERE idclientes = ?";

            PreparedStatement stmt = conecta.prepareStatement(cmdsql);

            stmt.setInt(1, obj.getIdclientes());

            stmt.execute();
            stmt.close();

        } catch (SQLException erro) {
            throw new RuntimeException(erro);
        }
    }

    // Método para listar todos os clientes
    public List<Clientes> listarClientes() {
        try {
            List<Clientes> lista = new ArrayList<>();

            String cmdSql = "SELECT * FROM tbclientes";

            PreparedStatement stmt = conecta.prepareStatement(cmdSql);

            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Clientes c = new Clientes();
                c.setIdclientes(rs.getInt("idclientes"));
                c.setNometbclientes(rs.getString("nometbclientes"));
                c.setEnderecotbclientes(rs.getString("enderecotbclientes"));
                c.setNtbclientes(rs.getString("ntbclientes"));
                c.setBairrotbclientes(rs.getString("bairrotbclientes"));
                 c.setCidadetbclientes(rs.getString("cidadetbclientes"));
                c.setTelefonetbclientes(rs.getString("telefonetbclientes"));
               

                lista.add(c);
            }
            return lista;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    // Método para listar clientes por nome
    public List<Clientes> listarClientesPorNome(String nome) {
        try {
            List<Clientes> lista = new ArrayList<>();

            String cmdSql = "SELECT * FROM tbclientes WHERE nometbclientes LIKE ?";

            PreparedStatement stmt = conecta.prepareStatement(cmdSql);
            stmt.setString(1, "%" + nome + "%");

            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Clientes c = new Clientes();
                c.setIdclientes(rs.getInt("idclientes"));
                c.setNometbclientes(rs.getString("nometbclientes"));
                c.setEnderecotbclientes(rs.getString("enderecotbclientes"));
                 c.setEnderecotbclientes(rs.getString("ntbclientes"));
                  c.setEnderecotbclientes(rs.getString("bairrotbclientes"));
                c.setCidadetbclientes(rs.getString("cidadetbclientes"));
                c.setTelefonetbclientes(rs.getString("telefonetbclientes"));

                lista.add(c);
            }
            return lista;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    // Método para efetuar login
    public boolean efetuarLogin(String login, String senha) {
        try {
            // Criar o comando SQL
            String cmdsql = "SELECT * FROM tbusuarios WHERE login = ? AND senha = ?";

            // Organizar o cmdsql e executá-lo
            PreparedStatement stmt = conecta.prepareStatement(cmdsql);

            stmt.setString(1, login);
            stmt.setString(2, senha);

            ResultSet rs = stmt.executeQuery();

            // Verificar se foi encontrado algum registro
            if (rs.next()) {
                // Faz o login
                return true;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public byte[] obterFotoClientePorId(int idCliente) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
