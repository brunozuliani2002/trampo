package DAO;

import java.sql.*;

public class ConnectionFactory {

    public Connection conecta() {

        try {
            return DriverManager.getConnection("jdbc:mysql://localhost:3306/trampo", "root", "memelo01");
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
