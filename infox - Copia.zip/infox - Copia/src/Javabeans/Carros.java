package Javabeans;


/**
 *
 * @author usuario
 */
public class Carros {
    private int idcarros;
    private String nomecarros; // Alteração do nome da variável
    private int anocarros; // Alteração do nome da variável
    private String corcarros; // Alteração do nome da variável
    private int valorcarros; // Alteração do nome da variável
    private byte[] fotocarros; // Alteração do nome da variável

    public byte[] getFotocarros() {
        return fotocarros;
    }

    public void setFotocarros(byte[] fotocarros) {
        this.fotocarros = fotocarros;
    }

    public int getIdcarros() {
        return idcarros;
    }

    public void setIdcarros(int idcarros) {
        this.idcarros = idcarros;
    }

    public String getNomecarros() {
        return nomecarros;
    }

    public void setNomecarros(String nomecarros) {
        this.nomecarros = nomecarros;
    }

    public int getAnocarros() {
        return anocarros;
    }

    public void setAnocarros(int anocarros) {
        this.anocarros = anocarros;
    }

    public String getCorcarros() {
        return corcarros;
    }

    public void setCorcarros(String corcarros) {
        this.corcarros = corcarros;
    }

    public int getValorcarros() {
        return valorcarros;
    }

    public void setValorcarros(int valorcarros) {
        this.valorcarros = valorcarros;
    }
}
