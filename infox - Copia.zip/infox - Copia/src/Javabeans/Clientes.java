package Javabeans;

/**
 *
 * @author usuario
 */
public class Clientes {

    private int idclientes;
    private String nometbclientes; // Alteração do nome da variável
    private String telefonetbclientes; // Alteração do nome da variável
    private String enderecotbclientes; // Alteração do nome da variável
    private String cidadetbclientes;
    private String bairrotbclientes;
    private String ntbclientes;

    public String getBairrotbclientes() {
        return bairrotbclientes;
    }

    public void setBairrotbclientes(String bairrotbclientes) {
        this.bairrotbclientes = bairrotbclientes;
    }

    public String getNtbclientes() {
        return ntbclientes;
    }

    public void setNtbclientes(String ntbclientes) {
        this.ntbclientes = ntbclientes;
    }

    public String getCidadetbclientes() {
        return cidadetbclientes;
    }

    public void setCidadetbclientes(String cidadetbclientes) {
        this.cidadetbclientes = cidadetbclientes;
    }
    private String login;
    private String senha;

    public int getIdclientes() {
        return idclientes;
    }

    public void setIdclientes(int idclientes) {
        this.idclientes = idclientes;
    }

    public String getNometbclientes() {
        return nometbclientes;
    }

    public void setNometbclientes(String nometbclientes) {
        this.nometbclientes = nometbclientes;
    }

    public String getTelefonetbclientes() {
        return telefonetbclientes;
    }

    public void setTelefonetbclientes(String telefonetbclientes) {
        this.telefonetbclientes = telefonetbclientes;
    }

    public String getEnderecotbclientes() {
        return enderecotbclientes;
    }

    public void setEnderecotbclientes(String enderecotbclientes) {
        this.enderecotbclientes = enderecotbclientes;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }
}
